package com.freegunity.freegunity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedeSocialApplicationTests {

	@Test
	void contextLoads() {
	}

}
